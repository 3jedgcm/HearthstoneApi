package fr.coopuniverse.api.pokeapi.activity.singleton

import fr.coopuniverse.api.pokeapi.activity.data.Account

object Store {
    var test : String = "Coucou"
    var account : Account? = null
}