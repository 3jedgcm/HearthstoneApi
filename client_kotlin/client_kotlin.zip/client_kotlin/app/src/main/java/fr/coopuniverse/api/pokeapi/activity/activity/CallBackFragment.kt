package fr.coopuniverse.api.pokeapi.activity.activity

interface CallBackFragment {
    fun setFragment(dest:Destination)
}