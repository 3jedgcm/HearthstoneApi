package fr.coopuniverse.api.pokeapi.activity.activity

enum class Destination {
    Home,
    Market,
    Craft,
    Melt,
    Quizz,
    Shop,
    Exchange,
    Settings,
    Inventory,
    CardDetail
}